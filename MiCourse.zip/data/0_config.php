<?php
$db_url=SAE_MYSQL_HOST_M;
$db_user=SAE_MYSQL_USER;
$db_upwd=SAE_MYSQL_PASS;
$db_name=SAE_MYSQL_DB;
$db_port=SAE_MYSQL_PORT;
