<?php
header('Content-Type:application/json;charset=uft-8');
$mid=$_REQUEST['mid'];
include('0_config.php');
$conn=mysqli_connect($db_url,$db_user,$db_upwd,$db_name,$db_port);
$sql="set names utf-8";
mysqli_query($conn,$sql);
$sql="select mc_newCourse.mimg,mc_newCourse.mname ,mc_score.snumber, mc_department.dname from mc_newCourse,mc_score,mc_department where mc_newCourse.mid='$mid' AND mc_score.sid=mc_newCourse.scoreId AND mc_department.did=mc_newCourse.departmentId";
$result=mysqli_query($conn,$sql);
$list=mysqli_fetch_assoc($result);
echo json_encode($list);