<?php
header('Content-Type:application/json;charset=uft-8');
$conn=mysqli_connect('127.0.0.1','root','root','mc','3306');
$sql="set names utf-8";
mysqli_query($conn,$sql);
$sql="select mc_newCourse.mimg,mc_newCourse.mname ,mc_score.snumber, mc_department.dname from mc_newCourse,mc_score,mc_department where mc_newCourse.mid=3 AND mc_score.sid=mc_newCourse.scoreId AND mc_department.did=mc_newCourse.departmentId";
$result=mysqli_query($conn,$sql);
$list=mysqli_fetch_all($result,MYSQLI_ASSOC);
$str=json_encode($list);
echo $str;