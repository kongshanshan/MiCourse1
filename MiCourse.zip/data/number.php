<?php
header('Content-Type:application/json;charset=utf-8');
$sid=$_REQUEST['sid'];
include('0_config.php');
$conn=mysqli_connect($db_url,$db_user,$db_upwd,$db_name,$db_port);
$sql='set names utf-8';
mysqli_query($conn,$sql);
$sql="select * from mc_newCourse where scoreId='$sid'";
$result=mysqli_query($conn,$sql);
$list=mysqli_fetch_all($result,MYSQLI_ASSOC);
echo json_encode($list);