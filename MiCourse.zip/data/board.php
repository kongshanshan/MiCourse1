<?php
header('Content-Type:application/json;charset=uft-8');
$bid=$_REQUEST['bid'];
$output=[];
include('0_config.php');
$conn=mysqli_connect($db_url,$db_user,$db_upwd,$db_name,$db_port);
$sql="set names utf-8";
mysqli_query($conn,$sql);
$sql="select bname from mc_board where bid='$bid'";
$result=mysqli_query($conn,$sql);
$list=mysqli_fetch_assoc($result);
$output['title']=$list['bname'];
$sql="select * from mc_allBoard where boardId='$bid'";
$result=mysqli_query($conn,$sql);
$list=mysqli_fetch_all($result,MYSQLI_ASSOC);
$output['content']=$list;
//echo json_encode($output['content']);
echo json_encode($output);