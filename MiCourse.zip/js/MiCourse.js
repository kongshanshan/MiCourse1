
var app = angular.module('myApp', ['ng','ngRoute']);
app.controller('parentCtrl', function ($scope,$http,$location) {
  $scope.jump=function(path) {
    $location.path(path);
  };
  $scope.search=true;
    $scope.$watch('kw',function(){
      //console.log($scope.kw);
      //$scope.search=false;
      if($scope.kw){
        $http.get('data/getbykw.php?kw='+$scope.kw)
          .success(function(data){
            $scope.list=data;
            $scope.search=false;
          })
      }
    })
  $scope.no=function(){
    $scope.search=true;
    $scope.kw='';
  }
  $scope.logo=true;
  $scope.login=function(){
    $scope.logo=false;
  }
  $scope.hide=function(){
    $scope.logo=true;
  }
});
app.controller('mainCtrl',function($scope,$http){
  $scope.list=['img/film.jpg','img/mineral.jpg','img/biology.jpg','img/uncertainty.jpg',
            'img/pollution.jpg',
            'img/usa.jpg'];
  $('#myTab a').click(function(e){
    e.preventDefault();
    $(this).tab('show')
  });
  $http.get('data/department.php')
    .success(function(data){
      $scope.department=data;
      //console.log($scope.department);

    })
})
app.controller('courseCtrl',['$scope','$http',
  function($scope,$http){
    $http.get('data/course.php')
      .success(function(data){
        $scope.list=data;
      })
  }
])
app.controller('boardCtrl',['$scope','$http',
  function($scope,$http){
    $http.get('data/board.php?bid=1')
      .success(function(data){
        $scope.list=data;
        $scope.ti=$scope.list.title;
        $scope.n=$scope.list.content;
      });
    $scope.lis=[
      {a:"active"},{a:""},{a:""},{a:""}
    ];
    $scope.board=function(num){
      var n=3;
      for(var i=0;i<=n;i++){
        if(i==num-1){
          $scope.lis[num-1].a='active';
        }else {
          $scope.lis[i].a = '';
        }
      }
      $http.get('data/board.php?bid='+num)
        .success(function(data){
          $scope.list=data;
          $scope.ti=$scope.list.title;
          $scope.n=$scope.list.content;
        })
    }

}])

app.controller('detailCtrl',['$scope','$http','$routeParams',function($scope,$http,$routeParams){
  //console.log($routeParams.mid);
  $scope.hasMore=true;
  $scope.detail=function(){
    if($('.descript-more').html()=="查看更多"){
      //$('.panel_content').show()
      $scope.hasMore=false;
      $('.descript-more').html('收起')
    }else{
      //$('.panel_content').hide();
      $scope.hasMore=true;
      $('.descript-more').html('查看更多')
    }
  };
  $http.get('data/course_detail.php?mid='+$routeParams.mid)
    .success(function(data){
        $scope.list=data;
    })
}])
app.controller('departmentCtrl',['$scope','$http','$routeParams',function($scope,$http,$routeParams){
    //console.log($routeParams.did)
  $http.get('data/department_course.php?did='+$routeParams.did)
    .success(function(data){
      $scope.department=data;
    })

}])
app.controller('typeCtrl',['$scope','$http','$routeParams',function($scope,$http,$routeParams){
    //console.log($routeParams.tid)
  $http.get('data/department_course.php?did='+$routeParams.tid)
    .success(function(data){
      $scope.type=data;
    })

}])
app.controller('numberCtrl',['$scope','$http','$routeParams',function($scope,$http,$routeParams){
    console.log($routeParams.sid)
  $http.get('data/number.php?sid='+$routeParams.sid)
    .success(function(data){
      $scope.number=data;
    })

}])
app.config(function($routeProvider){
  $routeProvider
    .when('/main',{
      templateUrl:'tpl/main.html',
      controller:'mainCtrl'
    })
    .when('/course',{
      templateUrl:'tpl/course.html',
       controller:'courseCtrl'
    })
    .when('/board',{
      templateUrl:'tpl/board.html',
      controller:'boardCtrl'
    })
    .when('/course_detail/:mid',{
      templateUrl:'tpl/course_detail.html',
      controller:'detailCtrl'
    })
    .when('/department/:did',{
      templateUrl:'tpl/department_course.html',
      controller:'departmentCtrl'
    })
    .when('/type/:tid',{
      templateUrl:'tpl/type.html',
      controller:'typeCtrl'
    })
    .when('/number/:sid',{
      templateUrl:'tpl/number.html',
      controller:'numberCtrl'
    })
    .otherwise({redirectTo:'/main'})
})

